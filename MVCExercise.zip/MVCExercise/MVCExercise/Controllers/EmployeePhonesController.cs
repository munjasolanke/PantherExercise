﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVCExercise.Models;

namespace MVCExercise.Controllers
{
    public class EmployeePhonesController : Controller
    {
        private PantherExerciseEntities db = new PantherExerciseEntities();

        // GET: EmployeePhones
        public ActionResult Index(string searchString)
        {

            //var employeePhones = db.EmployeePhones.Include(e => e.Employee);
            return View(db.EmployeePhones.Where(s =>s.PhoneNumber.Contains(searchString)||searchString==null).ToList());
        }

        // GET: EmployeePhones/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeePhone employeePhone = db.EmployeePhones.Find(id);
            if (employeePhone == null)
            {
                return HttpNotFound();
            }
            return View(employeePhone);
        }

        // GET: EmployeePhones/Create
        public ActionResult Create()
        {
            ViewBag.EmployeeId = new SelectList(db.Employees, "EmployeeId", "EmployeeNumber");
            return View();
        }

        // POST: EmployeePhones/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EmployeePhoneId,EmployeeId,PhoneType,PhoneNumber")] EmployeePhone employeePhone)
        {
            if (ModelState.IsValid)
            {
                db.EmployeePhones.Add(employeePhone);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.EmployeeId = new SelectList(db.Employees, "EmployeeId", "EmployeeNumber", employeePhone.EmployeeId);
            return View(employeePhone);
        }

        // GET: EmployeePhones/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeePhone employeePhone = db.EmployeePhones.Find(id);
            if (employeePhone == null)
            {
                return HttpNotFound();
            }
            ViewBag.EmployeeId = new SelectList(db.Employees, "EmployeeId", "EmployeeNumber", employeePhone.EmployeeId);
            return View(employeePhone);
        }

        // POST: EmployeePhones/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EmployeePhoneId,EmployeeId,PhoneType,PhoneNumber")] EmployeePhone employeePhone)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employeePhone).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.EmployeeId = new SelectList(db.Employees, "EmployeeId", "EmployeeNumber", employeePhone.EmployeeId);
            return View(employeePhone);
        }

        // GET: EmployeePhones/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeePhone employeePhone = db.EmployeePhones.Find(id);
            if (employeePhone == null)
            {
                return HttpNotFound();
            }
            return View(employeePhone);
        }

        // POST: EmployeePhones/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EmployeePhone employeePhone = db.EmployeePhones.Find(id);
            db.EmployeePhones.Remove(employeePhone);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
